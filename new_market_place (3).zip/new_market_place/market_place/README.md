# Marketplace (Unified Products)

This repo contains:
- server/ : Express backend with /api/products and a seed script
- client/ : Vite + React frontend with a single Products page

Quick start:
1. In server/: copy .env.example -> .env and set MONGO_URI
2. npm install (in server and client)
3. npm run seed (in server) to add sample products
4. npm start (in server)
5. npm run dev (in client)
