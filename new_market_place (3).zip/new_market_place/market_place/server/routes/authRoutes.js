import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'mysecretkey'; // Use environment variable

// Register new user - UPDATED VERSION
router.post('/register', async (req, res) => {
  try {
    const { 
      firstName, 
      lastName, 
      username, 
      email, 
      password, 
      phone, 
      gender, 
      dateOfBirth, 
      role = 'buyer' 
    } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [{ email }, { username }] 
    });
    
    if (existingUser) {
      return res.status(400).json({ 
        message: 'User with this email or username already exists' 
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create new user
    const newUser = await User.create({ 
      firstName,
      lastName,
      username,
      email, 
      password: hashedPassword,
      phone,
      gender,
      dateOfBirth,
      role,
      profile: {
        firstName,
        lastName,
        phone,
        gender
      }
    });

    // Generate JWT token
    const token = jwt.sign(
      { userId: newUser._id, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: newUser._id,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        username: newUser.username,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        isSellerVerified: newUser.role === 'seller' ? false : true
      }
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ 
      message: 'Registration failed. Please try again.',
      error: err.message 
    });
  }
});

// Seller Registration - NEW ENDPOINT
router.post('/register/seller', async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      username,
      email,
      password,
      phone,
      gender,
      dateOfBirth,
      businessName,
      businessType,
      taxId,
      establishmentDate,
      businessAddress,
      annualTurnover,
      website,
      description
    } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [{ email }, { username }] 
    });
    
    if (existingUser) {
      return res.status(400).json({ 
        message: 'User with this email or username already exists' 
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create new user with seller role
    const newUser = await User.create({
      firstName,
      lastName,
      username,
      email,
      password: hashedPassword,
      phone,
      gender,
      dateOfBirth,
      role: 'seller',
      profile: {
        firstName,
        lastName,
        phone,
        gender
      },
      businessDetails: {
        businessName,
        businessType,
        taxId,
        establishmentDate,
        businessAddress,
        annualTurnover,
        website,
        description,
        isVerified: false // Will be verified after admin approval
      }
    });

    // Generate JWT token
    const token = jwt.sign(
      { userId: newUser._id, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      message: 'Seller registered successfully! Verification pending.',
      token,
      user: {
        id: newUser._id,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        username: newUser.username,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        isSellerVerified: false,
        businessName: newUser.businessDetails.businessName
      }
    });

  } catch (error) {
    console.error('Seller registration error:', error);
    res.status(500).json({ 
      message: 'Seller registration failed. Please try again.', 
      error: error.message 
    });
  }
});

// Login user - FIXED VERSION
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate token and send response
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isSellerVerified: user.businessDetails?.isVerified || false,
        businessName: user.businessDetails?.businessName
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get current user profile
router.get('/profile', async (req, res) => {
  try {
    // This would typically use middleware to verify token
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(decoded.userId).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        email: user.email,
        phone: user.phone,
        role: user.role,
        isSellerVerified: user.businessDetails?.isVerified || false,
        businessName: user.businessDetails?.businessName,
        profile: user.profile,
        businessDetails: user.businessDetails
      }
    });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;