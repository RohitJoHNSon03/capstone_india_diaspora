# Marketplace Server (Unified Products)

## Setup
1. Copy `.env.example` to `.env` and set `MONGO_URI`.
2. Install dependencies: `npm install`
3. Seed sample products (optional): `npm run seed`
4. Start server: `npm start`

Routes:
- GET  /api/products
- POST /api/products
